package com.example.oasis.profilePage

class ProfileViewModel {
}