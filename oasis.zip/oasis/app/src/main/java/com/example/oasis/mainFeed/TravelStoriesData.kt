package com.example.oasis.mainFeed

data class TravelStoriesData (var travelImage: Int, var travelLocation: String, var traveler: String)

