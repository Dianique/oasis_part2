package com.example.oasis.profileFeed

import androidx.lifecycle.ViewModel

class TravelProfileViewModel: ViewModel() {

}
