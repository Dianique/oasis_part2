package com.example.oasis.profileFeed

data class TravelProfileData (var imageForProfile : Int, var title : String, var desc : String)